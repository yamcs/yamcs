package org.csstudio.opibuilder.widgetexample;

import org.csstudio.opibuilder.model.AbstractPVWidgetModel;
import org.csstudio.opibuilder.properties.DoubleProperty;
import org.csstudio.opibuilder.properties.WidgetPropertyCategory;
import org.eclipse.swt.graphics.RGB;

public class SimpleBarGraphModel extends AbstractPVWidgetModel{

	/** Lower limit of the widget. */
	public static final String PROP_MIN = "max"; //$NON-NLS-1$		
	
	/** Higher limit of the widget. */
	public static final String PROP_MAX = "min"; //$NON-NLS-1$		
	
	public final String ID = "org.csstudio.opibuilder.widgetExample.SimpleBarGraph"; //$NON-NLS-1$
	
	/**
	 * Initialize the properties when the widget is first created.
	 */
	public SimpleBarGraphModel() {
		setForegroundColor(new RGB(255, 0, 0));
		setBackgroundColor(new RGB(0,0,255));
		setSize(50, 100);
	}
	
	@Override
	protected void configureProperties() {
		addProperty(new DoubleProperty(PROP_MIN, "Min", WidgetPropertyCategory.Behavior, 0));
		addProperty(new DoubleProperty(PROP_MAX, "Max", WidgetPropertyCategory.Behavior, 100));
	}

	@Override
	public String getTypeID() {
		return ID;
	}
	
	/**
	 * @return the lower limit
	 */
	public double getMin(){
		return getCastedPropertyValue(PROP_MIN);
	}
	
	/**
	 * @return the higher limit
	 */
	public double getMax(){
		return getCastedPropertyValue(PROP_MAX);
	}
}
