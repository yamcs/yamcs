package org.csstudio.opibuilder.customScriptUtilExample;

import org.csstudio.opibuilder.scriptUtil.ConsoleUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

/**A BOY ScriptUtil example.
 * @author Xihui Chen
 *
 */
public class MyScriptUtil {
	
	/**
	 * Print <code>Hello World!</code> to console and dialog. 
	 */
	public static void helloWorld(){
		ConsoleUtil.writeInfo("Hello World!");
		MessageDialog.openInformation(Display.getCurrent().getActiveShell(), "Hello", 
				"MyScriptUtil says: Hello World!");
	}

}
